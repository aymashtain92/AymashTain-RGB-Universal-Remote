<#
    Repairs a broken install: recreates the virtual environment, reinstalls
    dependencies and reports the state of Bluetooth, audio and camera support.
    Run with:  powershell -ExecutionPolicy Bypass -File repair.ps1
#>

$ErrorActionPreference = "Stop"
Set-Location -Path $PSScriptRoot

$python = Get-Command py -ErrorAction SilentlyContinue
if (-not $python) { $python = Get-Command python -ErrorAction SilentlyContinue }
if (-not $python) { throw "Python 3.10+ not found. Install from https://python.org" }

if (Test-Path ".venv") {
    Write-Host "Removing old virtual environment..."
    Remove-Item -Recurse -Force ".venv"
}

Write-Host "Creating virtual environment..."
& $python.Source -3 -m venv .venv 2>$null
if (-not (Test-Path ".venv\Scripts\python.exe")) { & $python.Source -m venv .venv }

$venv = ".\.venv\Scripts\python.exe"
& $venv -m pip install --upgrade pip
& $venv -m pip install -r requirements.txt

Write-Host "`nChecking optional subsystems..."
& $venv -c @"
for name in ('PySide6', 'qasync', 'bleak', 'numpy', 'sounddevice', 'soundfile', 'cv2'):
    try:
        __import__(name)
        print(f'  ok      {name}')
    except Exception as exc:
        print(f'  MISSING {name}: {exc}')
"@

$service = Get-Service -Name bthserv -ErrorAction SilentlyContinue
if ($service) { Write-Host "  Bluetooth support service: $($service.Status)" }
else { Write-Host "  Bluetooth support service not present" }

Write-Host "`nDone. Start the app with run.bat"
